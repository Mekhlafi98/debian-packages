functions.add('foo', function() {
    return 'bar';
});